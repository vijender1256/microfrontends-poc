import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { OverlayModule } from "@angular/cdk/overlay";
import { PortalModule } from "@angular/cdk/portal";
import { CdkScrollableModule } from "@angular/cdk/scrolling";
import { A11yModule } from "@angular/cdk/a11y";
import { MatButtonModule } from "@angular/material/button";
import { MatFormFieldModule } from "@angular/material/form-field";
import { MatInputModule } from "@angular/material/input";
import { MatIconModule } from "@angular/material/icon";
import { MatRippleModule } from "@angular/material/core";
import { MatDividerModule } from "@angular/material/divider";
import { MatClockDialsComponent } from "./components/clock-dials";
import { MatHoursClockDialComponent } from "./components/hours-clock-dial";
import { MatMinutesClockDialComponent } from "./components/minutes-clock-dial";
import {
  MatTimeInputsComponent,
  MatHourInputDirective,
  MatMinuteInputDirective,
} from "./components/time-inputs";
import { MatTimePeriodComponent } from "./components/time-period";
import { MatTimepickerComponent } from "./components/timepicker";
import {
  MatTimepickerActionsComponent,
  MatTimepickerDefaultActionsComponent,
  MatTimepickerApplyDirective,
  MatTimepickerCancelDirective,
} from "./components/timepicker-actions";
import { MatTimepickerContentComponent } from "./components/timepicker-content";
import { MatTimepickerContentLayoutComponent } from "./components/timepicker-content-layout";
import { MatTimepickerInputDirective } from "./directives/timepicker-input";
import { MatTimepickerIntl } from "./other/timepicker-intl";
import { MAT_TIMEPICKER_SCROLL_STRATEGY_FACTORY_PROVIDER } from "./other/timepicker-scroll-strategy";
import {
  MatTimepickerToggleComponent,
  MatTimepickerToggleIconDirective,
} from "./components/timepicker-toggle";
import { MAT_DEFAULT_ACITONS } from "./other/timepicker-actions-default";

@NgModule({
  declarations: [
    MatTimepickerToggleComponent,
    MatTimepickerToggleIconDirective,
    MatTimepickerComponent,
    MatTimepickerContentComponent,
    MatTimepickerContentLayoutComponent,
    MatTimepickerInputDirective,
    MatTimeInputsComponent,
    MatHourInputDirective,
    MatMinuteInputDirective,
    MatClockDialsComponent,
    MatHoursClockDialComponent,
    MatMinutesClockDialComponent,
    MatTimePeriodComponent,
    MatTimepickerActionsComponent,
    MatTimepickerDefaultActionsComponent,
    MatTimepickerApplyDirective,
    MatTimepickerCancelDirective,
  ],
  imports: [
    CommonModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatRippleModule,
    MatDividerModule,
    OverlayModule,
    PortalModule,
    A11yModule,
  ],
  exports: [
    CdkScrollableModule,
    MatTimepickerToggleComponent,
    MatTimepickerToggleIconDirective,
    MatTimepickerComponent,
    MatTimepickerContentComponent,
    MatTimepickerContentLayoutComponent,
    MatTimepickerInputDirective,
    MatTimeInputsComponent,
    MatHourInputDirective,
    MatMinuteInputDirective,
    MatClockDialsComponent,
    MatHoursClockDialComponent,
    MatMinutesClockDialComponent,
    MatTimepickerActionsComponent,
    MatTimepickerDefaultActionsComponent,
    MatTimepickerApplyDirective,
    MatTimepickerCancelDirective,
  ],
  providers: [
    MatTimepickerIntl,
    MAT_TIMEPICKER_SCROLL_STRATEGY_FACTORY_PROVIDER,
    { provide: Window, useValue: window },
    {
      provide: MAT_DEFAULT_ACITONS,
      useValue: MatTimepickerDefaultActionsComponent,
    },
  ],
})
export class MatTimepickerModule {}
