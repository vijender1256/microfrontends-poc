import {
  Component,
  ChangeDetectionStrategy,
  ViewEncapsulation,
  OnInit,
  OnDestroy,
  Optional,
  NgZone,
  ElementRef,
  HostBinding,
} from "@angular/core";
import { BehaviorSubject, Subscription, take } from "rxjs";
import { TimeAdapter } from "../adapter";
import { MatTimeFaceBaseDirective } from "../directives/time-face-base";
import { withZeroPrefixMeridiem } from "../directives/time-input-base";
import { MatTimepickerIntl } from "../other/timepicker-intl";

export type MatDialView = "hours" | "minutes";

@Component({
  selector: "ui-components-mat-clock-dials",
  templateUrl: "./clock-dials.html",
  styleUrls: ["./clock-dials.scss"],
  exportAs: "matClockDials",
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
})
export class MatClockDialsComponent<T>
  extends MatTimeFaceBaseDirective<T>
  implements OnInit, OnDestroy
{
  @HostBinding("class") classes = "mat-clock-dials";
  @HostBinding("attr.role") role = "dial";

  isHoursView = true;

  /** Specifies the view of clock dial. */
  private readonly _view = new BehaviorSubject<MatDialView>("hours");
  private _viewSubscription: Subscription | null = Subscription.EMPTY;

  constructor(
    public _intl: MatTimepickerIntl,
    @Optional() _timeAdapter: TimeAdapter<T>,
    private _ngZone: NgZone,
    private _elementRef: ElementRef
  ) {
    super(_timeAdapter);
  }

  ngOnInit(): void {
    this._viewSubscription = this._view.subscribe(
      (view) => (this.isHoursView = view === "hours")
    );
  }

  ngOnDestroy(): void {
    this._viewSubscription?.unsubscribe();
    this._viewSubscription = null;
  }

  /** Changes clock dial view. */
  onViewChange(view: MatDialView): void {
    this._view.next(view);
  }

  focusActiveCell(): void {
    this._ngZone.runOutsideAngular(() => {
      this._ngZone.onStable.pipe(take(1)).subscribe(() => {
        setTimeout(() => {
          const activeCell: HTMLElement | null =
            this._elementRef.nativeElement.querySelector(
              ".mat-clock-dial-cell-active"
            );

          if (activeCell) {
            activeCell.focus();
          }
        });
      });
    });
  }

  _withZeroPrefix(value: number): string {
    if (value === 0) {
      return "00";
    }

    return withZeroPrefixMeridiem(value, this.isMeridiem);
  }

  /** Handles hour selection. */
  _onHourChanged(hour: number): void {
    this._view.next("minutes");
    this._onHourSelected(hour);
  }
}
