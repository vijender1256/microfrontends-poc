import {
  Component,
  ChangeDetectionStrategy,
  Directive,
  ViewEncapsulation,
  Input,
  ContentChild,
  Attribute,
  HostBinding,
  HostListener,
} from "@angular/core";
import { BooleanInput, coerceBooleanProperty } from "@angular/cdk/coercion";
import { MatTimepickerComponent } from "./timepicker";
import { MatTimepickerIntl } from "../other/timepicker-intl";

@Directive({ selector: "[uiComponentsTimepickerToggleIcon]" })
export class MatTimepickerToggleIconDirective {}

@Component({
  selector: "ui-components-mat-timepicker-toggle",
  templateUrl: "./timepicker-toggle.html",
  styleUrls: ["./timepicker-toggle.scss"],
  exportAs: "matTimepickerToggle",
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MatTimepickerToggleComponent<T> {
  @HostBinding("class") classes = "mat-timepicker-toggle";
  @HostBinding("attr.tabindex") tabindex = null;
  @HostListener("click", ["$event"]) clicked(e: Event) {
    this.open(e);
  }
  /** Timepicker instance. */
  @Input() timepicker!: MatTimepickerComponent<T>;

  /** Whether the toggle button is disabled. */
  @Input()
  get disabled(): boolean {
    if (this._disabled === undefined && this.timepicker) {
      return this.timepicker.disabled;
    }

    return !!this._disabled;
  }
  set disabled(value: BooleanInput) {
    this._disabled = coerceBooleanProperty(value);
  }
  private _disabled!: boolean;

  /** Whether ripples on the toggle should be disabled. */
  @Input()
  disableRipple!: boolean;

  /** Tabindex for the toggle. */
  @Input() tabIndex: number | null;

  /** Custom icon set by the consumer. */
  @ContentChild(MatTimepickerToggleIconDirective)
  customIcon!: MatTimepickerToggleIconDirective;

  /** Screen-reader label for the button. */
  @Input("aria-label")
  ariaLabel!: string;

  constructor(
    @Attribute("tabindex") defaultTabIndex: string,
    public _intl: MatTimepickerIntl
  ) {
    const parsedTabIndex = Number(defaultTabIndex);
    this.tabIndex =
      parsedTabIndex || parsedTabIndex === 0 ? parsedTabIndex : null;
  }

  /** Opens timepicker. */
  open(event: Event): void {
    if (this.timepicker && !this.disabled) {
      this.timepicker.open();
      event.stopPropagation();
    }
  }
}
