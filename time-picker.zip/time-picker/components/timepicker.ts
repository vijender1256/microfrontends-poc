import {
  ChangeDetectionStrategy,
  Component,
  HostBinding,
  ViewEncapsulation,
} from "@angular/core";
import {
  MatTimepickerBaseDirective,
  MatTimepickerControl,
} from "../directives/timepicker-base";
import { MAT_SINGLE_TIME_SELECTION_MODEL_PROVIDER } from "../models/time-selection-model";

@Component({
  selector: "ui-components-mat-timepicker",
  template: "",
  exportAs: "matTimepicker",
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
  providers: [
    MAT_SINGLE_TIME_SELECTION_MODEL_PROVIDER,
    {
      provide: MatTimepickerBaseDirective,
      useExisting: MatTimepickerComponent,
    },
  ],
})
export class MatTimepickerComponent<T> extends MatTimepickerBaseDirective<
  MatTimepickerControl<T>,
  T | null,
  T
> {
  @HostBinding("class") classes = "mat-timepicker";
  @HostBinding("class.mat-primary") get prime() {
    return this.color !== "accent" && this.color !== "warn";
  }
  @HostBinding("class.mat-accent") get accent() {
    return this.color === "accent";
  }
  @HostBinding("class.mat-warn") get warn() {
    return this.color === "warn";
  }
}
