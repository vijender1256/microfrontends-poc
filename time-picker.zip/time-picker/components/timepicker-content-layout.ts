import {
  ChangeDetectionStrategy,
  Component,
  HostBinding,
  Input,
  ViewEncapsulation,
} from "@angular/core";

@Component({
  selector: "ui-components-mat-timepicker-content-layout",
  templateUrl: "./timepicker-content-layout.html",
  styleUrls: ["./timepicker-content-layout.scss"],
  exportAs: "matTimepickerContent",
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None,
})
export class MatTimepickerContentLayoutComponent {
  @HostBinding("class") classes = "mat-timepicker-content-layout";

  /** Content title. */
  @Input()
  title!: string;
}
