import {
  Directive,
  ElementRef,
  forwardRef,
  HostBinding,
  HostListener,
  Inject,
  Input,
  Optional,
} from "@angular/core";
import {
  NG_VALIDATORS,
  NG_VALUE_ACCESSOR,
  ValidatorFn,
  Validators,
} from "@angular/forms";
import { ThemePalette } from "@angular/material/core";
import { MatFormField, MAT_FORM_FIELD } from "@angular/material/form-field";
import { MAT_INPUT_VALUE_ACCESSOR } from "@angular/material/input";
import { TimeAdapter } from "../adapter/time-adapter";
import { MatTimepickerInputBaseDirective } from "./timepicker-input-base";
import { TimeSelectionModelChange } from "../models/time-selection-model";
import { MatTimepickerControl, MatTimepickerPanel } from "./timepicker-base";

export const MAT_TIMEPICKER_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => MatTimepickerInputDirective),
  multi: true,
};

export const MAT_TIMEPICKER_VALIDATORS: any = {
  provide: NG_VALIDATORS,
  useExisting: forwardRef(() => MatTimepickerInputDirective),
  multi: true,
};

/** Directive used to connect an input to a MatTimepicker. */
@Directive({
  selector: "[uiComponentsTimepicker]",
  exportAs: "matTimepickerInput",
  providers: [
    MAT_TIMEPICKER_VALUE_ACCESSOR,
    MAT_TIMEPICKER_VALIDATORS,
    {
      provide: MAT_INPUT_VALUE_ACCESSOR,
      useExisting: MatTimepickerInputDirective,
    },
  ],
})
export class MatTimepickerInputDirective<T>
  extends MatTimepickerInputBaseDirective<T | null, T>
  implements MatTimepickerControl<T | null>
{
  @HostBinding("class") classes = "mat-timepicker-input";
  @HostBinding("attr.tabindex") tabindex = null;
  @HostBinding("attr.aria-haspopup") get haspop() {
    return this._timepicker ? "dialog" : null;
  }
  // @HostBinding("attr.aria-owns") get owns() {
  //   return (this._timepicker?.opened && this._timepicker.id) || null
  // }
  @HostBinding("disabled") get disable() {
    return this.disabled;
  }
  @HostListener("input", ["$event"]) _input(e: any) {
    this._onInput(e.target.value);
  }
  @HostListener("change") _change() {
    this._onChange();
  }
  @HostListener("blur") _blur() {
    this._onBlur();
  }
  /** The timepicker that this input is associated with. */
  @Input()
  set uiComponentsTimepicker(
    timepicker: MatTimepickerPanel<MatTimepickerControl<T>, T | null, T>
  ) {
    if (timepicker) {
      this._timepicker = timepicker;
      this._registerModel(timepicker.registerInput(this));
    }
  }
  _timepicker!: MatTimepickerPanel<MatTimepickerControl<T>, T | null, T>;

  /** The combined form control validator for this input. */
  protected _validator: ValidatorFn | null;

  /** The minimum valid date. */
  @Input()
  get min(): T | null {
    return this._min;
  }
  set min(value: T | null) {
    const validValue = this._timeAdapter.getValidTimeOrNull(
      this._timeAdapter.deserialize(value)
    );

    if (!this._timeAdapter.sameTime(validValue, this._min)) {
      this._min = validValue;
      this._validatorOnChange();
    }
  }
  private _min!: T | null;

  /** The maximum valid date. */
  @Input()
  get max(): T | null {
    return this._max;
  }
  set max(value: T | null) {
    const validValue = this._timeAdapter.getValidTimeOrNull(
      this._timeAdapter.deserialize(value)
    );

    if (!this._timeAdapter.sameTime(validValue, this._max)) {
      this._max = validValue;
      this._validatorOnChange();
    }
  }
  private _max!: T | null;

  constructor(
    elementRef: ElementRef<HTMLInputElement>,
    @Optional() timeAdapter: TimeAdapter<T>,
    @Optional() @Inject(MAT_FORM_FIELD) private _formField?: MatFormField
  ) {
    super(elementRef, timeAdapter);
    this._validator = Validators.compose(super._getValidators());
  }

  /**
   * Gets the element that the timepicker popup should be connected to.
   * @return The element to connect the popup to.
   */
  getConnectedOverlayOrigin(): ElementRef {
    return this._formField
      ? this._formField.getConnectedOverlayOrigin()
      : this._elementRef;
  }

  /** Returns the palette used by the input's form field, if any. */
  getThemePalette(): ThemePalette {
    return this._formField ? this._formField.color : undefined;
  }

  /** Gets the ID of an element that should be used a description for the timepicker overlay. */
  getOverlayLabelId(): string | null {
    if (this._formField) {
      return this._formField.getLabelId();
    }

    return this._elementRef.nativeElement.getAttribute("aria-labelledby");
  }

  /** Gets the input's minimum time. */
  _getMinTime() {
    return this._min;
  }

  /** Gets the input's maximum time. */
  _getMaxTime() {
    return this._max;
  }

  protected _assignValueToModel(value: T | null): void {
    if (this._model) {
      this._model.updateSelection(value, this);
    }
  }

  protected _getValueFromModel(modelValue: T | null): T | null {
    return modelValue;
  }

  protected _shouldHandleChangeEvent(event: TimeSelectionModelChange<T>) {
    return event.source !== this;
  }
}
